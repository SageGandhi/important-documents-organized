export class SimpleDonutChart {
    name: string = ''
    value: string = ''
    color: string = ''
}

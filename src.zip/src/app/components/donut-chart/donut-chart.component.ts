import { Component, Input, OnInit } from '@angular/core';
import { SimpleDonutChart } from 'src/app/model/simple-donut-chart';
import * as d3 from 'd3';

@Component({
  selector: 'app-donut-chart',
  templateUrl: './donut-chart.component.html',
  styleUrls: ['./donut-chart.component.css']
})
export class DonutChartComponent implements OnInit {
  private radius: number;

  @Input("data") private data: SimpleDonutChart[] = [
    // For Test Purposes Only - You Can UnComment This Code
    { name: "Correct", value: "10", color: "#665faac" },
    { name: "Incorrect", value: "10", color: "#dd8050c4" },
    { name: "Not Attempted", value: "10", color: "#63adfeb3" }
  ];
  private margin = { top: 10, right: 10, bottom: 10, left: 10 };
  @Input('width') width: number = 500;
  @Input('height') height: number = 500;
  
  constructor() {
    this.radius = Math.min(this.width, this.height) / 2 - this.margin.left;
  }

  ngOnInit(): void {
    //Creating Scalable Vector Graphics
    const svg = d3.select(`#quiz-attempt`).append('svg').attr('width', `${this.width}`).attr('height', `${this.height}`)
      .append('g').attr('transform', `translate(${this.width / 2},${this.height / 2})`);
    //Creating Colors For Scalable Vector Graphics
    const colors = d3.scaleOrdinal().domain(this.data.map((d: any) => d.value)).range(this.data.map(item => item.color));
    //Drawing Chart As Required
    const pie = d3.pie().value((d: any) => d.value);
    // The Arc Generator
    const arc = d3.arc().innerRadius(this.radius * 0.5).outerRadius(this.radius * 0.8);
    //Writing To Shadow Virtual Model Arc Creation
    svg.selectAll("allSlices").data(pie(<any>this.data)).enter().append("path").attr("d", <any>arc)
      .attr("fill", (d: any) => <any>colors(d.data.color)).attr("stroke", "white")
      .style("stroke-width", "2px").style("opacity", 0.875);
    //Writing Legends Within Donut Hole
    const legendItemSize = 18, legendSpacing = 4;
    //Create Legend Group As Rectangle & Text Holder
    const legend = svg.selectAll('.legend').data(this.data).enter().append('g').attr('class', 'legend')
      .attr('transform', (d: any, i: number) => {
        const height = legendItemSize + legendSpacing,
          offset = height * this.data.length / 2,
          x = legendItemSize * -2,
          y = (i * height) - offset;
        return `translate(${x}, ${y})`;
      })
    //Color Full Rectangle Added
    legend.append('rect').attr('width', legendItemSize - 2).attr('height', legendItemSize - 2)
      .style('fill', (d: any) => d.color).attr("transform", "translate(-15,0)");
    //Same Color Text Added With Count
    legend.append('text').attr('x', legendItemSize + legendSpacing).attr('y', legendItemSize - legendSpacing)
      .style('fill', (d: any) => d.color).text((d: any) => `${d.name}(${d.value})`)
      .attr('transform', 'translate(-15,0)');
  }
}

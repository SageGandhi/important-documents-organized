import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-d3';
  allQuiz: number[] = [];
  constructor() {
    for (let index = 1; index <= 100; index++) {
      this.allQuiz.push(index);
    }
  }
}

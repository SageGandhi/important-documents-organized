package edu.gandhi.prajit.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCucumberIntegrationAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCucumberIntegrationAppApplication.class, args);
	}

}

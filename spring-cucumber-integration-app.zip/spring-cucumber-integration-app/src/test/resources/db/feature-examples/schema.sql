drop table if exists known_person;
create table known_person(first_name varchar(255),last_name varchar(255),identifier integer);
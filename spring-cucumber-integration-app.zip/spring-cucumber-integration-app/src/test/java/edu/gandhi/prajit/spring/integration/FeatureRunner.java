package edu.gandhi.prajit.spring.integration;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        plugin = {
                "progress",
                "html:build/report/cucumber/html",
                "junit:build/report/cucumber/junit/integration.xml",
                "json:build/report/cucumber/json/integration.json"
        },
        tags = "not @EF",
        snippets = CucumberOptions.SnippetType.CAMELCASE
)
public class FeatureRunner {

}

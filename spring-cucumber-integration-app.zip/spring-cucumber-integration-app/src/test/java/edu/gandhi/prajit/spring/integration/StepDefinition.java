package edu.gandhi.prajit.spring.integration;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.web.client.RestOperations;

import javax.sql.DataSource;

@CucumberContextConfiguration
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class StepDefinition {
    @LocalServerPort
    protected int port;
    @Autowired
    protected RestOperations restOperations;
    @Autowired
    protected JdbcOperations jdbcOperations;
    @Autowired
    protected DataSource dataSource;
    @Value("classpath:db/feature-examples/schema.sql")
    private Resource resourceSchemaSql;
    @Value("classpath:db/feature-examples/data.sql")
    private Resource resourceDataSql;
    private DataTable dataTable;
    private ResponseEntity<String> response;

    @Before
    public void initializeDatabase() {
        final ResourceDatabasePopulator resourceDatabasePopulator = new ResourceDatabasePopulator();
        resourceDatabasePopulator.addScript(resourceSchemaSql);
        resourceDatabasePopulator.addScript(resourceDataSql);

        final DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
        dataSourceInitializer.setDataSource(dataSource);
        dataSourceInitializer.setDatabasePopulator(resourceDatabasePopulator);
        dataSourceInitializer.afterPropertiesSet();
    }

    @Given("following {string} exists in the database with corresponding column values")
    public void followingExistsInTheDatabaseWithCorrespondingColumnValues(String columnName, DataTable dataTable) {
        System.out.println("Getting Column Name From Given Statement:" + columnName);
        System.out.println("Getting Iterated Data From Example Table To DataTable, One Example Table Row At A Time");
        dataTable.asLists().stream().forEach(System.out::println);
    }

    @Given("following database record identified by below criteria")
    public void followingDatabaseRecordIdentifiedByBelowCriteria(DataTable dataTable) {
        System.out.println("Here We Prepare For Request Invocation,Database Data Setup Based On Data Provided In Data Table/Example Table");
        //All Member Variables Will Be Refreshed/Re-Initialize
        dataTable.asLists().stream().forEach(System.out::println);
    }

    @When("request is sent to api service")
    public void requestIsSentToApiService() {
        //Call Actual Rest API Endpoint & Get Response Here
        response = restOperations.getForEntity("http://localhost:{port}/version", String.class, Integer.toString(port));
    }

    @Then("the attribute {string}.{string} should be populated with the value {string}")
    public void theAttributeShouldBePopulatedWithTheValue(String table, String column, String expectedValue) {
        System.out.println("Response Saved In When Step" + response);
        jdbcOperations.queryForList("select * from known_person").stream().forEach(System.out::println);
        System.out.println("Query Based On Existing Value In Database Along With Previously Saved Json Response & Step Definition Values Like: Table" +
                table + ",Column:" + column + ", Expected Value:" + expectedValue);
    }

    @TestConfiguration
    public static class SpringContext {
        @Bean
        public RestOperations restOperations(RestTemplateBuilder builder) {
            return builder.build();
        }
    }
}
